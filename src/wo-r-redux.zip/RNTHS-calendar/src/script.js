/*
 * Copyright © 2019-2025 Wo-r (https://github.com/wo-r)
 * 
 * Dependencys: 
 *  - jQuery v3.7.1
 *  - Tailwind v3.4.16
 * 
 * Website: https://wo-r.github.io
 * Built: 2025-04-04T00:00Z
 */
(async function ($, window, document) {
    "use strict";


    
})(jQuery, window, document);