/**
 * Runs the projects portion of the site.
 */
export async function run() {
}