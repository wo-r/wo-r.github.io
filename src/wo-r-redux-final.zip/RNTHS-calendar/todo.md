


Pages:

Projects
About me
Contact
Resume
Portfolio
Certifications
Experience
Education


Redo script files (LATER but still do it)


Redo the main page [who i am] section since safeinsight cut the trainee program