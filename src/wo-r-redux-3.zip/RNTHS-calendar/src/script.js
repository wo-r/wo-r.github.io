/*
 * Copyright © 2019-2025 Wo-r (https://github.com/wo-r)
 * 
 * Dependencys: 
 *  - jQuery v3.7.1
 *  - Tailwind v3.4.16
 * 
 * Website: https://wo-r.github.io
 * Built: 2025-04-04T00:00Z
 */
(async function ($, window, document) {
    "use strict";


    // CURRENTLY IN DEBUG THIS WILL PROBABLY MASSIVLY CHANGE


    $("#content #navbar #navbarToggle").click(function () {
        const dropdown = $("#navbarDropdown");
        const iconPath = $("#navbarToggle svg path");
        const closePath = "M480-385 302-207q-20 20-48 20t-47-20q-20-20-20-47.5t20-47.5l178-178-178-179q-20-20-20-47.5t20-47.5q19-20 47-20t48 20l178 178 178-178q20-20 48-20t47 20q20 20 20 47.5T753-659L575-480l178 178q20 20 20 47.5T753-207q-19 20-47 20t-48-20L480-385Z";
        const defaultPath = "M140-159q-27.45 0-46.73-20Q74-199 74-227.32q0-28.31 18.77-47.5Q111.55-294 140-294h172q27.45 0 46.73 19.93Q378-254.14 378-225.82q0 28.31-18.77 47.57Q340.45-159 312-159H140Zm0-255q-27.45 0-46.73-19.5Q74-453 74-482.32q0-28.31 18.77-47Q111.55-548 140-548h425q28.45 0 47.72 19.43Q632-509.14 632-480.82q0 29.31-18.78 48.07Q594.45-414 565-414H140Zm0-254q-27.45 0-46.73-20Q74-708 74-736.32q0-29.31 19.5-48Q113-803 142-803h678q27.45 0 46.72 19.43Q886-764.14 886-734.82q0 28.31-19.5 47.57Q847-668 818-668H140Z"; // example hamburger
    
        if (dropdown.is(":visible")) {
            dropdown.stop(true, true).slideUp(300).fadeOut(200, function () {
                dropdown.addClass("hidden");
            });
            iconPath.attr("d", defaultPath);
        } else {
            dropdown.stop(true, true).hide().removeClass("hidden").slideDown(300).fadeIn(200);
            iconPath.attr("d", closePath);
        }
    });




    
})(jQuery, window, document);